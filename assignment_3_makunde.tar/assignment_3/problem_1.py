"""Create a robust temperature converter program that takes input in Fahrenheit and converts to Celsius. 
You program should make no assumptions about the user input. Use the try/except pattern to ensure that the user has entered valid input.

Think of all the possible ways this could fail. We will try our best to break your program."""

AFTER_INCORRECT_INPUT = "Please enter a positive, whole number numeric temperature: "

def temp_converter():
    f = None
    prompt = "Enter a temperature in Farenheit: "
    while f == None:
        try:
            f = float(input(prompt))
        except ValueError:
            prompt = AFTER_INCORRECT_INPUT

    # Formula for conversion https://www.calculatorsoup.com/calculators/conversions/fahrenheit-to-celsius.php
    c = round((f - 32) / (9/5), 2)
    print(f"The temperature is {c} in Celsius.")


temp_converter()