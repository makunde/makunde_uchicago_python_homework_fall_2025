from bidict import bidict

"""
The Caeser cipher is a simple encryption technique where each
letter is shifted in the alphabet. For example, with a shift
of 1, A would replaced by B, B would be replaced by C, and
so on. This cipher was used by Julius Caesar to communicate
with his generals.

The following is an example of a shift, or key, of 5.

Plain: ABCDEFGHIJKLMNOPQRSTUVWXYZ
Cipher: FGHIJKLMNOPQRSTUVWXYZABCDE
To encrypt and decrypt a message, both parties need to
know what the key is.

The following example shows a message encrypted with a
key of 23.

Plaintext: THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG
Ciphertext: QEB NRFZH YOLTK CLU GRJMP LSBO QEB IXWV ALD
Write two functions, one that encrypts a string with a
given key and one that decrypts a function with a given
key.


Provide an example of your function working with a key
of 12 and using the following quote from Julius Caesar:

Experience is the teacher of all things.
"""
MAPPING = bidict({"A": 0, "B": 1, "C": 2, "D": 3, "E": 4, "F": 5, "G": 6, "H": 7,
    "I": 8, "J": 9, "K": 10, "L": 11, "M": 12, "N": 13, "O": 14, "P": 15,
    "Q": 16, "R": 17, "S": 18, "T": 19, "U": 20, "V": 21, "W": 22, "X": 23,
    "Y": 24, "Z": 25})

def caesar_encrypt(key, message):
    encryption = ""
    for char in message.upper():
        if char == " ":
            encryption += " "
            continue
        new_char_int = MAPPING[char] + key
        new_char_int = within_map_size(new_char_int)
        encryption += MAPPING.inverse[new_char_int]
    return encryption

"""decrypt caesar"""
def caesar_decrypt(key, message):
    return caesar_encrypt(-1*key, message)

def within_map_size(num):
    return num % len(MAPPING)

# print(caesar_encrypt(23, "THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG"))
# print(caesar_decrypt(23, "QEB NRFZH YOLTK CLU GRJMP LSBO QEB IXWV ALD"))