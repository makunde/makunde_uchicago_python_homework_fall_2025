"""The centered average is the mean average ignoring the largest and smallest values.
 For examples the centered average of the following collection of numbers, [1,4,5,6,100] is 5.

Write a function that returns the centered average of an array of numbers.
 If there are multiple copies of the smallest value, keep only one. 
 Likewise for the largest value.

Use floating point precision for division to produce the final average.
 Make sure to test to that the array has a length of at least 3 (the 
 smallest list that can be used to computer a centered average).

You should write 2 distinct functions to solve this problem using 
different approaches. In the first implementation, use iteration 
techniques. In the second, you are not allowed to use iteration. 
Hint: Take note of the built-in capabilities of Python's list 
data structure."""

def centered_average_iteration(num_list):
    greatest_i = 0
    lowest_i = 0
    highest = num_list[0]
    lowest = num_list[0]
    if len(num_list) < 3:
        return None
    for i in range(len(num_list)):
        if num_list[i] > highest:
            highest = num_list[i]
            greatest_i = i
        if num_list[i] < lowest:
            lowest = num_list[i]
            lowest_i = i
    num_list.pop(greatest_i)
    if greatest_i < lowest_i:
        lowest_i -= 1
    num_list.pop(lowest_i)
    return round(sum(num_list)/len(num_list), 2)

def centered_average(num_list):
    num_list = sorted(num_list)
    num_list.pop()
    num_list.pop(0)
    return round(sum(num_list)/len(num_list), 2)

print(centered_average_iteration([2,4,5,1,100]))
print(centered_average_iteration([4,100,5,61, 6,15,3,5,1,10, 78]))
print(centered_average([2,4,5,1,100]))
print(centered_average([4,100,5,61, 6,15,3,5,1,10, 78]))
