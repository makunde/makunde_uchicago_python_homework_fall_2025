"""Text analysis can be a powerful tool to understand your data.
There are many machine learning algorithms that use text analysis
to infer similarity based on shared properties between a corpus of
documents. For this problem, you will do a word count analysis of
the speech "I Have a Dream" by Martin Luther King Jr.

Read the file speech.txt and count the frequency of each word.
To get more meaningful results of our analysis, we will want
to remove the most commonly used words in the English language
(ie. there is little to be gained from knowing how many times
the word "the" was used). Use the common_words.txt file to
exclude these words from your analysis.

Wite the results of your analysis out to a file by listing
the twenty most frequently used words in the order from most
to least frequent. Include teh number of times they appear.
Follow the format presented below:"""
import problem_4

def get_distribution(speech):
    sequence_tracker = {}
    for word in speech:
        if word not in sequence_tracker:
            sequence_tracker[word] = 1
        else:
            sequence_tracker[word] += 1
    speech_word_count = len(speech)
    distribution_list = []
    for key, value in sequence_tracker.items():
        distribution = value / speech_word_count
        distribution_list.append((key, distribution))
    return distribution_list

def get_top_20(distribution):
    sorted(distribution, key=lambda x: x[1], reverse=True)
    while len(distribution) > 20:
        distribution.pop()
    return distribution


def load_speech(filename):
    file = open(filename)
    speech_raw = file.read().splitlines()
    speech_raw = [word.strip() for word in speech_raw]
    speech = []
    for line in speech_raw:
        speech += line.split()
    english_dictionary = problem_4.process_file("assignment_3/common_words.txt")[1]
    i = 0
    while i < len(speech):
        if speech[i] in english_dictionary:
            speech.pop(i)
        else:
            i += 1
    return speech

def save_top_20_words(filename):
    speech = load_speech(filename)
    distribution = get_distribution(speech)
    top_20_words = get_top_20(distribution)
    with open("top_20.txt", "w") as f:
        for word in top_20_words:
            f.write(f"{word[0]} - {word[1]}\n")

save_top_20_words("assignment_3/speech.txt")