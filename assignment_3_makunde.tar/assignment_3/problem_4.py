"""Write a function that processes a text file. The function should take the filename as its only argument. The function
should read in the file, remove any whitespace and put the contents into a list that is sorted. You may use Python's 
built-in sorting methods. Make sure that you do any necessary error handling or validation that is required to gracefully
(ie. not crash) handle any potential issues with running your code.

The function should return the file name, a sorted list of the file content, and the number of lines in the file as a tuple.

Provide a code snippet that runs your function and prints the contents of the tuple to the screen.

# Snippet to run function
(filename, items, lines) = process_file("common_words.txt")
Use the common_words.txt file of the 1000 most common words in the English language for the function.
"""

def process_file(filename): 
    """Read, sort and return a file"""
    file = open(filename)
    words_list_unsorted = file.read().splitlines()
    words_list_unsorted = [word.strip() for word in words_list_unsorted]
    sorted_items = sorted(words_list_unsorted)

    return (filename, sorted_items, len(words_list_unsorted))

# print(process_file("assignment_3/common_words.txt"))
