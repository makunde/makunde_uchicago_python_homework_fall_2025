"""Using your solution to Problem 3 and information provided in Problem 4, crack the following Caesar Cipher encrypted message.

What is the key and what is the message?

mpwtpgp jzf nly lyo jzf lcp slwqhlj espcp
Write out your approach and any assumptions you made as a comment at the top of the file."""
import problem_3
import problem_4
# My approach was to brute force the key by interating 1-26 and checking if the output is in the dictionary provided in common_words.txt
# my assumption was that all the words provided would be in the dictionary this seems to not be the case with halfway so I used a confidence percentage to verify
# The message is "'BELIEVE', 'YOU', 'CAN', 'AND', 'YOU', 'ARE', 'HALFWAY', 'THERE'"
# key is 11

def brute_force_decrypt(message):
    decrypted_text = ""
    matches = 0
    english_dictionary = problem_4.process_file("assignment_3/common_words.txt")[1]
    for i in range(26):
        decrypted_text = problem_3.caesar_decrypt(i, message)
        decrypted_list = decrypted_text.split()
        for word in decrypted_list:
            if word.lower() in english_dictionary:
                matches+=1
        confidence = matches / len(decrypted_list)
        if confidence > .8:
            break
    if confidence < .8:
        return f"unable to decrypt \'{message}\'"
    return (decrypted_text, i)

print(brute_force_decrypt("mpwtpgp jzf nly lyo jzf lcp slwqhlj espcp"))
