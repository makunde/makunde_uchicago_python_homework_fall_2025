"""A point in three-dimensional space can be represented by its x, y, and z coordinates.
The distance between points, p and q, can be measured by the Euclidean distance d(p,q),
where:

Given the set of points in the points.txt file, answer the following questions:

Which point is closest to the origin (0.00, 0.00, 0.00)?
Which two points are closest to each other?"""
import math 

def distance(point_1_xyz, point_2_xyz):
    x1_minus_x2_squared = (float(point_1_xyz[0]) - float(point_2_xyz[0])) ** 2
    y1_minus_y2_squared = (float(point_1_xyz[1]) - float(point_2_xyz[1])) ** 2
    z1_minus_z2_squared = (float(point_1_xyz[2]) - float(point_2_xyz[2])) ** 2
    return math.sqrt(x1_minus_x2_squared + y1_minus_y2_squared + z1_minus_z2_squared)

def load_points(filename):
    file = open(filename)
    points_raw = file.read().splitlines()
    points = {}
    for rawpoint in points_raw:
        rawpoint_list = rawpoint.split(",")
        points[rawpoint_list[0]] = (rawpoint_list[1], rawpoint_list[2], rawpoint_list[3])
    return points

def closest(filename):
    points = load_points(filename)
    closest_distance = None
    closest_tuple = None
    compared = []
    for key, value in points.items():
        for nested_key, nested_value in points.items():
            if key == nested_key:
                continue
            if (key, nested_key) in compared or (nested_key, key) in compared:
                continue
            current_distance = distance(value, nested_value)
            compared.append((key, nested_key))
            compared.append((nested_key, key))
            if closest_distance is None:
                closest_distance = current_distance
                closest_tuple = (key, nested_key)
            elif current_distance < closest_distance:
                closest_distance = current_distance
                closest_tuple = (key, nested_key)
    return closest_tuple

def closest_to_target(filename, target_xyz):
    points = load_points(filename)
    closest_distance = None
    closest_point = None
    for key, value in points.items():
        current_distance = distance(value, target_xyz)
        if closest_distance is None:
            closest_distance = current_distance
            closest_point = key
        elif current_distance < closest_distance:
            closest_distance = current_distance
            closest_point = key
    return closest_point

print(closest("assignment_3/points.txt"))
print(closest_to_target("assignment_3/points.txt", (0, 0, 0)))
