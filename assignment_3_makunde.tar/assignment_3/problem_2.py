"""Complete the function that you worked on during Breakout Exercises
and write a function using pseudocode based on your list that returns
True if the string argument is a number:

def is_number(astring):

    # if number
    # return True
    # else
    # return False
You do not have to implement the function using approaches discussed
in class. There are solutions that could require 100 lines of code
and some that could require 10 lines of code. Think smartly about
what exactly you are trying to do and use everything you have
learned to decided how you will solve this problem."""

# attempt to convert the string to a float
# if no exceptions return true otherwise return false

def is_number(astring):
    try:
        float(astring)
        return True
    except ValueError:
        return False
    
print(is_number("2.3"))
print(is_number("-2.3"))
print(is_number("2.3000"))
print(is_number("2"))
print(is_number("2a"))